# from Inheritance.person_1.project.person import Person
from project.person import Person

class Child(Person):
    pass
