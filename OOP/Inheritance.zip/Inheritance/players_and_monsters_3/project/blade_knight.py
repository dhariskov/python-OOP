# from Inheritance.players_and_monsters_3.project.dark_knight import DarkKnight
from project.dark_knight import DarkKnight


class BladeKnight(DarkKnight):
    pass
    # def __init__(self, username, level):
    #     super().__init__(username, level)

