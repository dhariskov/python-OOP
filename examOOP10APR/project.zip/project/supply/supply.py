from abc import ABC, abstractmethod
from project.survivor import Survivor


class Supply(ABC):
    @abstractmethod
    def __init__(self, needs_increase: int):
        self._needs_increase = needs_increase

    @property
    def needs_increase(self):
        return self._needs_increase

    @needs_increase.setter
    def needs_increase(self, value):
        if value < 0:
            raise ValueError("Needs increase cannot be less than zero.")
        self._needs_increase = value

    #todo check it this breacks because of init static
    def apply(self, survivor: Survivor):
        survivor.needs += self.needs_increase
